#include <iostream>

int main (void)
{
  char c;

  do {
    std::cin >> c;
    std::cout << c;
  } while (c != '\n');

}
