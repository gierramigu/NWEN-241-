#include <iostream>

int main ()
{
  std::cout << std::showpos << 27 << std::endl;

  return 0;
}
