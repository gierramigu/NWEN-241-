#include <iostream>

int main()
{
  char buf[10];
  std::cin >> buf;
  std::cout << buf << std::endl;

return 0;
}
