/*
 * Tutorial for getchar() and putchar() functions
 */

#include <stdio.h>

int main (void)
{
	char c = getchar();
	putchar(c);

	char d = getchar();
	putchar(d);
}
