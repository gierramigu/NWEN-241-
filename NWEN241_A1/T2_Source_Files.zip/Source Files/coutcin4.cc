#include <iostream>

int main()
{
    char strBuf[11];
    std::cin.get(strBuf, 11);
    std::cout << strBuf << std::endl;

    return 0;
}
