#include <string>
#include <iostream>

int main()
{

    std::string strBuf;
    getline(std::cin, strBuf);
    std::cout << strBuf << std::endl;

    return 0;
}
