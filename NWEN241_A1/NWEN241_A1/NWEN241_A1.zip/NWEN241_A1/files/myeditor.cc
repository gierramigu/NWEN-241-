/**
 * myeditor.cc
 * 
 * You must implement the member functions, including constructors, of your class defined in myeditor.hh.
 * Consult the assignment handout for the detailed specifications of each of the member functions.
 * 
 * Student ID:
 * Name:
 */
