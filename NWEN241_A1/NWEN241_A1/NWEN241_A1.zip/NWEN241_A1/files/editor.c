/**
 * editor.c
 *
 * You must implement the functions in editor.h in this file.
 * Consult the assignment handout for the detailed specifications of each of the functions.
 *
 * Student ID: gierramigu
 * Name: Miguel Gierran
 */
#include <stdio.h>
#include "editor.h"
#include <stdlib.h>

// this main method calls the various from below with its specific parameters
int main(){

  char editing_buffer[EDITING_BUFLEN]= "The quick brown fox\0";
  int pos = 9;
  char to_insert = 's';
  editor_insert_char(editing_buffer, to_insert, pos);
  editor_delete_char(editing_buffer, to_insert, pos );

}

//task 1
int editor_insert_char(char *editing_buffer, char to_insert, int pos);{

  //editing_buflen array size = 2000
    for(int i = EDITING_BUFLEN-2; i >= pos-1; i--){
      editing_buffer[i+1] = editing_buffer[i];
    }

    editing_buffer[pos] = to_insert;
    printf("Output\n");

    for(int i = 0; i<= EDITING_BUFLEN; i++){
      print("%c", editing_buffer[i]);
    }

return 1;

}


//task 2
int editor_delete_char(char *editing_buffer, char to_delete, int offset){


      for(int i = EDITNG_BUFLEN-2 >= pos-1; i--){
          editing_buffer[i+1] = editing buffer[i];
      }

      editing_buffer[pos] = to_delete;
      print("Output\n");

      for(int i =0; i<=EDITING_BUFLEN; i++){
          print("%c", editing_buffer[i]);
      }


        return 0;

}


//task 3

int editor_replace_str(char *editing_buffer, const char *str, const char *replacement, int offset){

    printf(str );
    print(replacment);






}
